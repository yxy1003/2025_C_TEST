#include<cstdio>
#include<cstring>
const int N=55000;

int m,k;
int ans,l,r,n,a[N],a1[N];

int do1(int x){
	int num=0,lo=0;
	for(int i=1; i<=m; i++){
		if(a[i]-a[lo]<x){
			num++;
		}
		else{
			lo=i;
		}
		
	}
	if(num>k) return 0;
	return 1;
}
	
int main(){
	freopen("1.in","r",stdin);

	scanf("%d%d%d",&n,&m,&k);
	
	a[0]=0;
	for(int i=1; i<=m; i++){
		scanf("%d",&a[i]);
	}
	a[++m]=n;
	
	l=1; r=n;
	while(r>=l){
//		printf("%lld %lld\n",l,r);
		int mid=(l+r)>>1;
		
		if(do1(mid)){
			ans=mid;
			l=mid+1;
		}
		else{
			r=mid-1;
		} 
	}

	printf("%d",ans);	
	
	return 0;
}
