#include<cstdio>
const int N=1100;

struct node{
	int id;
	long long x;
};

node a[N];
int n;
long long nn;
double ans;

void qsort1(int l,int r){
	int i=l,j=r;
	node x=a[(l+r)>>1];
	while(i<=j){
		while(a[i].x<x.x or (a[i].x==x.x and a[i].id<x.id)) i++;
		while(x.x<a[j].x or (a[j].x==x.x and x.id<a[j].id)) j--;
		
		if(i<=j){
			node t=a[i]; a[i]=a[j]; a[j]=t;
			i++; j--;
		}
	}
	
	if(l<j) qsort1(l,j);
	if(i<r) qsort1(i,r);
	return;
}

int main(){
//	freopen("queue2.in","r",stdin);
//	freopen("queue2.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1; i<=n; i++){
		scanf("%lld",&a[i].x);
		a[i].id=i;
	}
	
	qsort1(1,n);
	
	for(int i=1; i<=n; i++){
		printf("%d ",a[i].id);
	}printf("\n");
	
	nn=n-1; ans=0;
	for(int i=1; i<=n-1; i++){
		ans+=a[i].x*nn;
		nn--;
	}
	
	printf("%.0lf\n",ans);
	
	return 0;
}
