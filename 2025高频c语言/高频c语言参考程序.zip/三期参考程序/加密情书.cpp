#include<cstdio>

unsigned int n;
unsigned int ans;

int main(){
//	freopen("encipher.in","r",stdin);
//	freopen("encipher.out","w",stdout); 
	
	scanf("%u",&n); 
	
	ans=(n<<16)+(n>>16);
	
	printf("%u",ans);
	
	return 0;
} 
