#include<cstdio>
#include<cstring>
const int N=110000;

int p1,p2,p3,l,num;
char a[N];

bool cck(int xx){ //�ж��Ƿ���д 
	char c1,c2;
	if(xx==0) return false; //���-���ַ�����β������д 
	if(xx==l-1) return false;
	
	c1=a[xx-1]; //�ҵ�-ǰ�����ĸ 
	c2=a[xx+1];
	
	//�ж��Ƿ�Ϊ������ĸ�����Һ���ĸ����ǰ��ĸ����Ϊ��д 
	if('a'<=c1 and c1<='z' and 'a'<=c2 and c2<='z' and c1<c2) return true; 
	if('A'<=c1 and c1<='Z' and 'A'<=c2 and c2<='Z' and c1<c2) return true;
	if('0'<=c1 and c1<='9' and '0'<=c2 and c2<='9' and c1<c2) return true;	
	
	//��������д 
	return false;
}

int main(){
//	freopen("expansion3.in","r",stdin);
//	freopen("expansion3.out","w",stdout);
	
	scanf("%d%d%d ",&p1,&p2,&p3); //���� 

	scanf("%s",a);
	l=strlen(a);
	
	num=0;
	while(num<l){ //û������ĩβ 
		if(a[num]=='-' and cck(num)){ //����������дʱ������������д�����ݴ�ӡ 
//			printf("%c\n",a[num-1]);
			
			if(p3==1){ //���� 
				if(p1==1){ //Сд��ĸ 
					if('0'<=a[num-1] and a[num-1]<='9'){ 
						for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
							for(int j=1; j<=p2; j++){ //��ʡ�����ݴ�ӡ 
								printf("%c",i);
							}
						}
					}
					if('a'<=a[num-1] and a[num-1]<='z'){
						for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
					if('A'<=a[num-1] and a[num-1]<='Z'){
						for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
							for(int j=1; j<=p2; j++){
								printf("%c",i-'A'+'a');
							}
						}
					}
				}
				if(p1==2){ //��д��ĸ 
					if('0'<=a[num-1] and a[num-1]<='9'){ 
						for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
					if('a'<=a[num-1] and a[num-1]<='z'){
						for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
							for(int j=1; j<=p2; j++){
								printf("%c",i-'a'+'A');
							}
						}
					}
					if('A'<=a[num-1] and a[num-1]<='Z'){
						for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
				}
				if(p1==3){ //�Ǻ� 
					for(char i=a[num-1]+1; i<=a[num+1]-1; i++){
						for(int j=1; j<=p2; j++){
							printf("%c",'*');
						}
					}
				}
			} 
			if(p3==2){ //���� 
				if(p1==1){ //Сд��ĸ 
					if('0'<=a[num-1] and a[num-1]<='9'){ 
						for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
					if('a'<=a[num-1] and a[num-1]<='z'){
						for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
					if('A'<=a[num-1] and a[num-1]<='Z'){
						for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
							for(int j=1; j<=p2; j++){
								printf("%c",i-'A'+'a');
							}
						}
					}
				}
				if(p1==2){ //��д��ĸ 
					if('0'<=a[num-1] and a[num-1]<='9'){ 
						for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
					if('a'<=a[num-1] and a[num-1]<='z'){
						for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
							for(int j=1; j<=p2; j++){
								printf("%c",i-'a'+'A');
							}
						}
					}
					if('A'<=a[num-1] and a[num-1]<='Z'){
						for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
							for(int j=1; j<=p2; j++){
								printf("%c",i);
							}
						}
					}
				}
				if(p1==3){ //�Ǻ� 
					for(char i=a[num+1]-1; i>=a[num-1]+1; i--){
						for(int j=1; j<=p2; j++){
							printf("%c",'*');
						}
					}
				}
			}
			
		}
		else{
			printf("%c",a[num]);
		}
		
		num++;
	}
	
	return 0;
} 
