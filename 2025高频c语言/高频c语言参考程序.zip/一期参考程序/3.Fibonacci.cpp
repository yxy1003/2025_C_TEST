#include <stdio.h>

int main(void) {
    int n;
    scanf("%d", &n);
    
    if(n%8==2 || n%8==6)
    {
		printf("yes");    	
	}
	else
    {
		printf("no");    	
	}
    
    return 0;
}
